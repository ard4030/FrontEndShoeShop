import { Skeleton } from 'antd';
const Sc_loading = () => {
 
 return(
    <Skeleton.Button active={true} size={'large'} shape={"default"} block={true} />
 )
}
export default Sc_loading;