import React from 'react'
import Menu from './Menu'
import styles from "./panel.module.css"

const ViewPanel = () => {
  return (
    // <div className={styles.contentPanel}>
    //     <Menu />
    //     <div></div>
    // </div>
    <>
    </>
  )
}

export default ViewPanel