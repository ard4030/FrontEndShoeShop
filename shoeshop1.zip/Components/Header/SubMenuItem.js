"use client"

const SubMenuItem = ({ title }) => {
  return (
    <li>
      <a href="#">{title}</a>
    </li>
  );
};

export default SubMenuItem;