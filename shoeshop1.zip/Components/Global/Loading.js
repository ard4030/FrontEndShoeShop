"use client"
import style from "./global.module.css"

const Loading = () => {
  return (
    <div className={style.loadComp}>
        <h1>Loading</h1>
    </div>
  )
}

export default Loading