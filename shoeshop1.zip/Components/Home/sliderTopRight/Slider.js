"use client"
import { useState, useEffect } from "react";
import styles from "./Slider.module.css";

const SliderTopRight = ({ slides, itemsPerRow = 2 }) => {
  return(
    <>
    </>
  )
};
export default SliderTopRight;