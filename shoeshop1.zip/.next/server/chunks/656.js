exports.id = 656;
exports.ids = [656];
exports.modules = {

/***/ 42656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _global_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11328);
/* harmony import */ var _global_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_global_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const Loading = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_global_module_css__WEBPACK_IMPORTED_MODULE_1___default().loadComp),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            children: "Loading"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loading);


/***/ }),

/***/ 11328:
/***/ ((module) => {

// Exports
module.exports = {
	"loadComp": "global_loadComp___8V38",
	"smallLoad": "global_smallLoad__0oFbr",
	"smImage": "global_smImage__3qGV2",
	"book": "global_book__2OvsY",
	"contLogin": "global_contLogin__2mAJ_",
	"childLigib": "global_childLigib__7p2vZ",
	"topImage": "global_topImage__9Ejku",
	"inputContMobile": "global_inputContMobile__dBpXE",
	"btnSendSms": "global_btnSendSms__1ib5W",
	"cls": "global_cls__JQEkJ",
	"iptOtp": "global_iptOtp__wPACq",
	"bading": "global_bading__eqELp",
	"headCartContent": "global_headCartContent__5KiGp",
	"orderStep": "global_orderStep__H45rL",
	"itemStep": "global_itemStep__AkqiB",
	"pkl": "global_pkl__4Ue3s"
};


/***/ })

};
;