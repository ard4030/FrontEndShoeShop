"use strict";
exports.id = 378;
exports.ids = [378];
exports.modules = {

/***/ 52378:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _panel_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(95798);
/* harmony import */ var _panel_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_panel_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _public_images_test_jpg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(41349);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(64348);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(40248);
/* harmony import */ var _utils_constans__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73385);
/* harmony import */ var _utils_constans__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_utils_constans__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Global_SmallLoad__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(39813);










const Book_dash = ({ width  })=>{
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const getData = async ()=>{
        setLoading(true);
        await axios__WEBPACK_IMPORTED_MODULE_7__/* ["default"].get */ .Z.get(`${_utils_constans__WEBPACK_IMPORTED_MODULE_3__.BASE_URL}/user/product/getBooksProduct`, {
            withCredentials: true
        }).then((response)=>{
            if (response.data.success) {
                setData(response.data.data);
            } else {
                alert(response.data.message);
            }
        }).catch((err)=>{
            alert(err.message);
        });
        setLoading(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getData();
    }, []);
    const deleteItem = async (productId)=>{
        setLoading(true);
        await axios__WEBPACK_IMPORTED_MODULE_7__/* ["default"].post */ .Z.post(`${_utils_constans__WEBPACK_IMPORTED_MODULE_3__.BASE_URL}/user/option/addBookmark`, {
            productId
        }, {
            withCredentials: true
        }).then((response)=>{
            if (response.data.success) {
                getData();
            } else {
                alert(response.data.message);
            }
        }).catch((err)=>{
            alert(err.message);
        });
        setLoading(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Global_SmallLoad__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            width: "49%",
            height: "100%"
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    style: {
                        width: width ? width : "100%"
                    },
                    className: (_panel_module_css__WEBPACK_IMPORTED_MODULE_8___default().headSec),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: "آخرین علاقه مندی ها"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_panel_module_css__WEBPACK_IMPORTED_MODULE_8___default().st1),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "flex-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_9__/* .MdArrowBackIosNew */ .lrP, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "fn10",
                                    children: "مشاهده همه"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_panel_module_css__WEBPACK_IMPORTED_MODULE_8___default().heart),
                    children: data && data.length > 0 && data.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    alt: "",
                                    src: `${_utils_constans__WEBPACK_IMPORTED_MODULE_3__.BASE_URL}${item.images[0]}`,
                                    width: 120,
                                    height: 120
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "defcolor",
                                    style: {
                                        height: "40px",
                                        overflow: "hidden",
                                        width: "100%"
                                    },
                                    children: item.e_name
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_panel_module_css__WEBPACK_IMPORTED_MODULE_8___default().action),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            onClick: ()=>router.push(`/product/${item._id}`),
                                            children: "مشاهده"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            onClick: ()=>{
                                                deleteItem(item._id);
                                            },
                                            children: "حذف"
                                        })
                                    ]
                                })
                            ]
                        }, index))
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Book_dash);


/***/ })

};
;