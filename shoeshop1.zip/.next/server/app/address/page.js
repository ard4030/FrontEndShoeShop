(() => {
var exports = {};
exports.id = 619;
exports.ids = [619];
exports.modules = {

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 95232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 41205:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(67797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(75183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(15815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(50515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'address',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 88688)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\address\\page.js"],
          
        }]
      },
        {
          'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19528)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\address\\loading.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 25968)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\layout.js"],
'error': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23025)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\error.js"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12879)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\loading.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\Project\\ShoeShopNext\\shoeshop1\\app\\address\\page.js"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/address/page"
  

/***/ }),

/***/ 25919:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94966))

/***/ }),

/***/ 94966:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page),
  "metadata": () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./Components/Address/address.module.css
var address_module = __webpack_require__(49363);
var address_module_default = /*#__PURE__*/__webpack_require__.n(address_module);
// EXTERNAL MODULE: ./node_modules/antd/lib/index.js
var lib = __webpack_require__(2318);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(40248);
// EXTERNAL MODULE: ./utils/constans.js
var constans = __webpack_require__(73385);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
;// CONCATENATED MODULE: ./Components/icons/Edit.js

const Edit = ({ width , height  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            version: "1.1",
            xmlnsXlink: "http://www.w3.org/1999/xlink",
            xmlnssvgjs: "http://svgjs.com/svgjs",
            width: width,
            height: height,
            x: "0",
            y: "0",
            viewBox: "0 0 24 24",
            xmlSpace: "preserve",
            className: "",
            children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                    dataname: "Layer 2",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M12.64 5.42 2.35 15.71a2.38 2.38 0 0 0-.68 1.41l-.41 3.6a1.81 1.81 0 0 0 1.81 2h.21l3.6-.41a2.42 2.42 0 0 0 1.41-.67l10.29-10.3zM22.06 4.55l-2.61-2.61a2.35 2.35 0 0 0-3.33 0L13.7 4.36l5.94 5.94 2.42-2.42a2.35 2.35 0 0 0 0-3.33z",
                        fill: "#808080",
                        dataoriginal: "#000000"
                    })
                })
            })
        })
    });
};
/* harmony default export */ const icons_Edit = (Edit);

;// CONCATENATED MODULE: ./Components/icons/Delete1.js

const Delete1 = ({ width , height  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            version: "1.1",
            xmlnsXlink: "http://www.w3.org/1999/xlink",
            xmlnssvgjs: "http://svgjs.com/svgjs",
            width: width,
            height: height,
            x: "0",
            y: "0",
            viewBox: "0 0 1024 1024",
            xmlSpace: "preserve",
            className: "",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M724.9 952.2h-423c-22.1 0-40.4-17.1-41.9-39.2l-36.3-539.6c-1.6-24.3 17.6-44.8 41.9-44.8h495.6c24.3 0 43.5 20.6 41.9 44.8L766.8 913c-1.5 22.1-19.8 39.2-41.9 39.2zm119.6-702.3h-657c-.6 0-1-.4-1-1V134c0-.6.4-1 1-1h657c.6 0 1 .4 1 1v114.8c0 .6-.4 1.1-1 1.1z",
                        fill: "#808080",
                        dataoriginal: "#000000",
                        className: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M690.9 189.5H339.8c-.6 0-1-.4-1-1V57.9c0-.6.4-1 1-1h351.1c.6 0 1 .4 1 1v130.6c0 .5-.4 1-1 1z",
                        fill: "#808080",
                        dataoriginal: "#000000",
                        className: ""
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const icons_Delete1 = (Delete1);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
// EXTERNAL MODULE: ./Context/AddressContext.js
var AddressContext = __webpack_require__(49071);
;// CONCATENATED MODULE: ./Components/Address/AddressList.js
/* __next_internal_client_entry_do_not_use__ default auto */ 




// import SimpleMap from '../global/NeshanMap';






const AddressList = ({ data  })=>{
    const [isModalOpen, setIsModalOpen] = (0,react_.useState)(false);
    const [showMap, setShowMap] = (0,react_.useState)(false);
    const [ostan, setIsOstan] = (0,react_.useState)([]);
    const [shahr, setIsShahr] = (0,react_.useState)([]);
    const { address , setOstan , setShahr , setAdd , setMobile , setPostalCode , setRes , setUpdate , activeItem , setActiveItem , activeType , setActiveType  } = (0,react_.useContext)(AddressContext.AddressContext);
    const router = (0,navigation.useRouter)();
    const [loading, setLoading] = (0,react_.useState)(false);
    const [myAdd, setMyAdd] = (0,react_.useState)(false);
    const [methods, setMethods] = (0,react_.useState)([]);
    const getMethods = async ()=>{
        await axios/* default.get */.Z.get(`${constans.BASE_URL}/user/post/getMethods`).then((response)=>{
            if (response.data.success) {
                setMethods(response.data.data);
                setActiveType(response.data.data[0]);
            } else {
                alert(response.data.message);
            }
        }).catch((err)=>{
            alert(err.message);
        });
    };
    const showModal = ()=>{
        setUpdate({
            ostan: "",
            shahr: "",
            address: "",
            mobile: "",
            postalCode: "",
            reciver: ""
        });
        setMyAdd(false);
        setIsModalOpen(true);
    };
    const handleOk = async ()=>{
        const data = {
            ostanName: address.ostan,
            cityName: address.shahr,
            name: address.reciver,
            mobile: address.mobile,
            postalCode: address.postalCode,
            description: address.address,
            lat: address.lat ? address.lat : "",
            lang: address.lang ? address.lang : "",
            id: myAdd._id
        };
        if (myAdd) {
            await axios/* default.post */.Z.post(`${constans.BASE_URL}/user/address/updateAddress`, data).then((response)=>{
                if (response.data.success) {
                    alert(response.data.message);
                    setIsModalOpen(false);
                    router.push("/address");
                } else {
                    if (response.data.messages) {
                        alert(JSON.stringify(response.data.messages));
                    } else {
                        alert(response.data.message);
                    }
                }
            }).catch((err)=>{
                alert(err.message);
            });
        } else {
            await axios/* default.post */.Z.post(`${constans.BASE_URL}/user/address/addAddress`, data).then((response)=>{
                if (response.data.success) {
                    alert(response.data.message);
                    setIsModalOpen(false);
                    router.push("address");
                } else {
                    if (response.data.messages) {
                        alert(JSON.stringify(response.data.messages));
                    } else {
                        alert(response.data.message);
                    }
                }
            }).catch((err)=>{
                alert(err.message);
            });
        // setIsModalOpen(false);
        }
    };
    const handleCancel = ()=>{
        setIsModalOpen(false);
    };
    const getOstan = async ()=>{
        // await axios.get('https://iran-locations-api.vercel.app/api/v1/states',{
        //     withCredentials: false
        //   }).then(response => {
        //     if(response.status == 200){
        //         setIsOstan(response.data)
        //     }else{
        //         alert(response.statusText)
        //     }
        // }).catch(err => {
        //     console.log(err)
        //     alert("خطا در دریافت لیست استان ها ")
        // })
        setIsOstan(constans.OSTANHA);
    };
    const getShahr = async (city)=>{
        setLoading(true);
        await axios/* default.get */.Z.get(`https://iran-locations-api.vercel.app/api/v1/cities?state=${city}`, {
            withCredentials: false
        }).then((response)=>{
            if (response.status == 200) {
                setIsShahr(response.data.cities);
            } else {
                alert(response.statusText);
            }
            setLoading(false);
        }).catch((err)=>{
            console.log(err);
            setLoading(false);
            alert("خطا در دریافت لیست استان ها ");
        });
    };
    const deleteItem = async (id)=>{
        setLoading(true);
        await axios/* default.post */.Z.post(`${constans.BASE_URL}/user/address/deleteAddress`, {
            id
        }).then((response)=>{
            if (response.data.success) {
                alert(response.data.message);
                router.push("/address");
            } else {
                alert(response.data.message);
            }
        }).catch((err)=>{
            alert(err.message);
        });
        setLoading(false);
    };
    const settingUpdate = async (data)=>{
        setUpdate({
            ostan: data.ostanName,
            shahr: data.cityName,
            address: data.description,
            mobile: data.mobile,
            postalCode: data.postalCode,
            reciver: data.name
        });
        setMyAdd(data);
        setIsModalOpen(true);
    };
    const newOrder = async ()=>{
        if (!activeItem || activeItem === false) {
            alert("آدرسی انتخاب نکردید!!");
            return;
        }
        if (!activeType || activeType === false) {
            alert("روش پستی را انتخاب کنید");
            return;
        }
        const data = {
            addressId: activeItem._id,
            postMethod: activeType._id
        };
        await axios/* default.post */.Z.post(`${constans.BASE_URL}/user/order/createOrder`, data, {
            withCredentials: true
        }).then((response)=>{
            if (response.data.success) {
                router.push("/final");
            } else {
                alert(response.data.message);
            }
        }).catch((err)=>{
            alert(err.message);
        });
    };
    (0,react_.useEffect)(()=>{
        getOstan();
        !activeItem && setActiveItem(data.data[0]);
        !activeType && setActiveType("پست پیشتاز");
        getMethods();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "ireg",
                                children: "آدرس های شما"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "dflex",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: showModal,
                                        className: "btnDef ml10",
                                        children: "افزودن آدرس"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: ()=>{
                                            newOrder();
                                        },
                                        className: "btnDef",
                                        children: "نهایی کردن سفارش"
                                    })
                                ]
                            })
                        ]
                    }),
                    data && data.data.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt15",
                        children: data && data.data.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                onClick: ()=>{
                                    setActiveItem(item);
                                },
                                className: `${(address_module_default()).contItem} ${activeItem._id && activeItem._id === item._id ? (address_module_default()).contItemActive : ""}`,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (address_module_default()).right,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (address_module_default()).bold,
                                                        children: "آدرس : "
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            " ",
                                                            item.ostanName,
                                                            " - شهر ",
                                                            item.cityName,
                                                            " - ",
                                                            item.description
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: (address_module_default()).bold,
                                                                children: "گیرنده : "
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: item.name
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: (address_module_default()).bold,
                                                                children: "کد پستی : "
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: item.postalCode
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: (address_module_default()).bold,
                                                                children: "تلفن : "
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: item.mobile
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: (address_module_default()).bold,
                                                                children: "موبایل : "
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: item.mobile
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (address_module_default()).left,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                onClick: ()=>{
                                                    settingUpdate(item);
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Edit, {
                                                    width: 20,
                                                    height: 20
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                onClick: ()=>{
                                                    deleteItem(item._id);
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Delete1, {
                                                    width: 20,
                                                    height: 20
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }, index))
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "آدرسی تا الان ثبت نکردید"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt60",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "ireg",
                        children: "انتخاب شیوه ارسال"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: methods && methods.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                onClick: ()=>{
                                    setActiveType(item);
                                },
                                className: `${(address_module_default()).contType} ${activeType && activeType.name === item.name ? (address_module_default()).contTypeActive : ""}`,
                                children: [
                                    item.name,
                                    " - ",
                                    item?.price
                                ]
                            }, index))
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(lib/* Modal */.u_, {
                title: "آدرس",
                open: isModalOpen,
                onOk: handleOk,
                onCancel: handleCancel,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (address_module_default()).forming,
                    children: [
                        !showMap && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `${(address_module_default()).formal} ${(address_module_default()).formal2}`,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            children: "استان"
                                        }),
                                        ostan && ostan.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx(lib/* Select */.Ph, {
                                            showSearch: true,
                                            style: {
                                                width: 200
                                            },
                                            placeholder: "Search to Select",
                                            optionFilterProp: "children",
                                            fieldNames: {
                                                label: "name",
                                                value: "id"
                                            },
                                            filterOption: (input, option)=>(option?.name ?? "").includes(input),
                                            filterSort: (optionA, optionB)=>(optionA?.name ?? "").localeCompare((optionB?.name ?? "").toLowerCase()),
                                            value: address.ostan,
                                            options: ostan,
                                            onChange: (e, b)=>{
                                                // setActiveOstan(b)
                                                setOstan(b);
                                                getShahr(b.name);
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            children: "شهر"
                                        }),
                                        (shahr.length > 0 || myAdd) && /*#__PURE__*/ jsx_runtime_.jsx(lib/* Select */.Ph, {
                                            showSearch: true,
                                            style: {
                                                width: 200
                                            },
                                            placeholder: "Search to Select",
                                            optionFilterProp: "children",
                                            fieldNames: {
                                                label: "name",
                                                value: "id"
                                            },
                                            filterOption: (input, option)=>(option?.name ?? "").includes(input),
                                            filterSort: (optionA, optionB)=>(optionA?.name ?? "").localeCompare((optionB?.name ?? "").toLowerCase()),
                                            options: shahr,
                                            value: address.shahr,
                                            onChange: (e, b)=>{
                                                setShahr(b);
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            children: "آدرس"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            value: address.address,
                                            onChange: (e)=>{
                                                setAdd(e.target.value);
                                            }
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `${(address_module_default()).formal} ${(address_module_default()).formal1} `,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            children: "نام گیرنده"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            value: address.reciver,
                                            onChange: (e)=>{
                                                setRes(e.target.value);
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            children: "موبایل"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            value: address.mobile,
                                            onChange: (e)=>{
                                                setMobile(e.target.value);
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            children: "تلفن ثابت"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {})
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            children: "کد پستی"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            value: address.postalCode,
                                            onChange: (e)=>{
                                                setPostalCode(e.target.value);
                                            }
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: ()=>{
                                    setShowMap(true);
                                },
                                className: "btnDef",
                                children: "انتخاب از روی نقشه"
                            })
                        }),
                        showMap && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: ()=>setShowMap(false),
                                children: "بستن"
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const Address_AddressList = (AddressList);

;// CONCATENATED MODULE: ./app/address/page.js
/* __next_internal_client_entry_do_not_use__ metadata,default auto */ 




const metadata = {
    title: "انتخاب آدرس",
    description: "Generated by create next app"
};
const Address = ()=>{
    const [data, setData] = (0,react_.useState)(null);
    const getData = async ()=>{
        await axios/* default.post */.Z.post(`${constans.BASE_URL}/user/address/getAddressById`, null, {
            withCredentials: true
        }).then((response)=>{
            if (response.data.success) {
                setData(response.data);
            } else {
                console.log(response.data.data);
            }
        }).catch((err)=>{
            console.log(err.messgae);
        });
    };
    (0,react_.useEffect)(()=>{
        getData();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "container",
        children: data && /*#__PURE__*/ jsx_runtime_.jsx(Address_AddressList, {
            data: data
        })
    });
};
/* harmony default export */ const page = (Address); // export async function getServerSideProps(context) {
 //   const { cookies } = context.req;
 //   const { headers } = context.req;
 //   console.log(headers)
 //   // تنظیم کوکی‌ها
 //   // const cookieJar = new tough.CookieJar();
 //   // const cookie1 = new tough.Cookie({
 //   //   key: 'token',
 //   //   value: cookies.token,
 //   //   domain: DOMAIN,
 //   //   path: '/',
 //   // });
 //   // const cookie2 = new tough.Cookie({
 //   //   key: 'deviceId',
 //   //   value: cookies.deviceId,
 //   //   domain: DOMAIN,
 //   //   path: '/',
 //   // });
 //   // cookieJar.setCookie(cookie1, BASE_URL);
 //   // cookieJar.setCookie(cookie2, BASE_URL);
 //   let data = {
 //     data:[],
 //     err:null
 //   };
 //   // اضافه کردن کوکی‌ها به درخواست
 //       // await axios.post(`${BASE_URL}/user/address/getAddressById`,null,{
 //       //   headers: {
 //       //     Cookie: cookieJar.getCookieStringSync(BASE_URL)
 //       //   },
 //       //   withCredentials:true
 //       // }).then(response => {
 //       //     if(response.data.success){
 //       //         data.data = response.data.data 
 //       //     }else{
 //       //       // data.err = response.data.messgae
 //       //         // console.log(response.data)
 //       //     }
 //       // }).catch(err => {
 //       //     console.log(err.messgae)
 //       // })
 //   // ارسال داده به کامپوننت
 //   return {
 //     props: {
 //       data,cookies
 //     },
 //   };
 // }


/***/ }),

/***/ 49363:
/***/ ((module) => {

// Exports
module.exports = {
	"right": "address_right__EVqLx",
	"contItem": "address_contItem____WFB",
	"bold": "address_bold__LTLvS",
	"left": "address_left__2LcSn",
	"forming": "address_forming__dnLzv",
	"formal": "address_formal__bpOmG",
	"formal1": "address_formal1__LRnyt",
	"formal2": "address_formal2__OGup5",
	"contItemActive": "address_contItemActive__2FYvm",
	"address_left": "address_address_left__fZ7xh",
	"contType": "address_contType__7RztF",
	"contTypeActive": "address_contTypeActive__hJEtH"
};


/***/ }),

/***/ 19528:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Loading = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: "Loading ..."
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loading);


/***/ }),

/***/ 88688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "metadata": () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(35985);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\app\address\page.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["metadata"];


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [859,956,343,318,359], () => (__webpack_exec__(41205)));
module.exports = __webpack_exports__;

})();