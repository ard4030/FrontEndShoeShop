(() => {
var exports = {};
exports.id = 489;
exports.ids = [489];
exports.modules = {

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 95232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 94404:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(67797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(75183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(15815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(50515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'product',
        {
        children: [
        '[productId]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19500)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\product\\[productId]\\page.js"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 25968)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\layout.js"],
'error': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23025)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\error.js"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12879)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\loading.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\Project\\ShoeShopNext\\shoeshop1\\app\\product\\[productId]\\page.js"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/product/[productId]/page"
  

/***/ }),

/***/ 75522:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3265))

/***/ }),

/***/ 3265:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Product_ProductView)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./Context/CartContext.js
var CartContext = __webpack_require__(67035);
// EXTERNAL MODULE: ./Context/ProductContext.js
var ProductContext = __webpack_require__(31475);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./Components/Global/SmallLoad.js + 1 modules
var SmallLoad = __webpack_require__(39813);
// EXTERNAL MODULE: ./Components/Product/product.module.css
var product_module = __webpack_require__(95170);
var product_module_default = /*#__PURE__*/__webpack_require__.n(product_module);
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var index_esm = __webpack_require__(75484);
;// CONCATENATED MODULE: ./Components/Product/Addcart.js






const Addcart = ({ data  })=>{
    const { addToCart , getIsBasking , addCount , deleteCount , setShow , show  } = (0,react_.useContext)(CartContext.CartContext);
    const { active  } = (0,react_.useContext)(ProductContext.ProductCtx);
    let is = getIsBasking(active);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: is ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (product_module_default()).contCart1,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsCartCheck */._tY, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    className: (product_module_default()).ising,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: ()=>{
                                addCount(active && active.addonItem, data._id);
                                setShow(true);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsPlus */.L3d, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: is.count
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: ()=>{
                                deleteCount(active && active.addonItem, data._id);
                                setShow(true);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsDash */.pZ2, {})
                        })
                    ]
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            onClick: ()=>{
                addToCart(active && active);
                setShow(true);
            },
            className: (product_module_default()).contCart,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsCartCheck */._tY, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: "افزودن به سبد خرید"
                })
            ]
        })
    });
};
/* harmony default export */ const Product_Addcart = (Addcart);

;// CONCATENATED MODULE: ./Components/Product/Attr.js
/* __next_internal_client_entry_do_not_use__ default auto */ 



const Attr = ({ title , value , index1  })=>{
    const { active , changeActive , basking  } = (0,react_.useContext)(ProductContext.ProductCtx);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).contColor,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: (product_module_default()).titleCont,
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (product_module_default()).itAtt,
                children: value && value.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        onClick: ()=>{
                            changeActive(title, item);
                        },
                        className: `${active && active.addonItem && active.addonItem[index1]?.key === item.key && (product_module_default()).itemAttrActive1} ${(product_module_default()).itemColor1} `,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: item.key
                        })
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const Product_Attr = (Attr);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-rating/lib/react-rating.cjs.js
var react_rating_cjs = __webpack_require__(29366);
var react_rating_cjs_default = /*#__PURE__*/__webpack_require__.n(react_rating_cjs);
;// CONCATENATED MODULE: ./Components/Product/Brands.js





const Brands = ({ data  })=>{
    console.log(data);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).cost,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (product_module_default()).brands,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (product_module_default()).bransimage,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2018/02/huawei.png",
                                fill: true,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "هواوی"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((react_rating_cjs_default()), {
                            initialRating: data.avgRate,
                            emptySymbol: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsStar */.RrZ, {
                                style: {
                                    color: "gold"
                                }
                            }),
                            fullSymbol: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsStarFill */.kRm, {
                                style: {
                                    color: "gold"
                                }
                            }),
                            readonly: true
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "fn12 lightcol mauto dblock tcenter inum",
                        children: [
                            "دیدگاه ",
                            data.comments.length,
                            " کاربر"
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_Brands = (Brands);

;// CONCATENATED MODULE: ./Components/Product/Cat.js


const Cat = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).cating,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "دسته"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: ":"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "موبایل"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "برچسب ها"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: ":"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: " کریستیانو ,"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: " مسی"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_Cat = (Cat);

;// CONCATENATED MODULE: ./Components/Product/ColorComp.js
/* __next_internal_client_entry_do_not_use__ default auto */ 




const ColorComp = ({ title , value , index1  })=>{
    const { active , changeActive  } = (0,react_.useContext)(ProductContext.ProductCtx);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).contColor,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: (product_module_default()).titleCont,
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (product_module_default()).itAtt,
                children: value && value.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        onClick: ()=>{
                            changeActive(title, item);
                        },
                        className: `${active && active.addonItem && active.addonItem[index1]?.key === item.key ? (product_module_default()).itemAttrActive : (product_module_default()).itemAttr} ${(product_module_default()).itemColor}`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: item.key
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                style: {
                                    background: item.value,
                                    color: item.value === "white" || item.value === "#fff" || item.value === "#ffffff" ? "black" : "#fff"
                                },
                                className: (product_module_default()).circleCol,
                                children: active && active.addonItem && active.addonItem[index1]?.key === item.key && /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsCheckLg */.IQF, {})
                            })
                        ]
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const Product_ColorComp = (ColorComp);

;// CONCATENATED MODULE: ./Components/Product/Heading.js


const Heading = ({ icon , title , e_name  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).contHH,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                children: icon
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: e_name
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_Heading = (Heading);

// EXTERNAL MODULE: ./node_modules/react-icons/bi/index.esm.js
var bi_index_esm = __webpack_require__(85228);
;// CONCATENATED MODULE: ./Components/Product/StarRating.js



function StarRating(props) {
    const { initialRating , onRatingChange  } = props;
    const handleRatingChange = (value)=>{
        onRatingChange(value);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx((react_rating_cjs_default()), {
        initialRating: initialRating,
        emptySymbol: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsStar */.RrZ, {
            style: {
                color: "gold"
            }
        }),
        fullSymbol: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsStarFill */.kRm, {
            style: {
                color: "gold"
            }
        }),
        onChange: handleRatingChange
    });
}
/* harmony default export */ const Product_StarRating = (StarRating);

// EXTERNAL MODULE: ./node_modules/antd/lib/index.js
var lib = __webpack_require__(2318);
// EXTERNAL MODULE: ./Context/AuthContext.js
var AuthContext = __webpack_require__(24980);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var fa_index_esm = __webpack_require__(16775);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(40248);
// EXTERNAL MODULE: ./utils/constans.js
var constans = __webpack_require__(73385);
;// CONCATENATED MODULE: ./Components/Product/AddCom.js
/* __next_internal_client_entry_do_not_use__ default auto */ 









const AddCom = ({ data  })=>{
    console.log(data);
    const { user , setViewLogin  } = (0,react_.useContext)(AuthContext.AuthContext);
    const [myData, setMydata] = (0,react_.useState)({
        rating: 0,
        keyfiat: 0,
        arzesh: 0,
        noavari: 0,
        emkanat: 0,
        sohoolat: 0,
        ghovTit: "",
        zafTit: "",
        message: "",
        ghovat: [],
        zaf: [],
        productId: data._id
    });
    const handleRatingChange = (value)=>{
        setMydata({
            ...myData,
            rating: value
        });
    };
    const handleChange = (val)=>{
        if (val === "ghov") {
            if (!myData.ghovat.includes(myData.ghovTit)) {
                setMydata({
                    ...myData,
                    ghovat: [
                        ...myData.ghovat,
                        myData.ghovTit
                    ]
                });
            }
        } else {
            if (!myData.zaf.includes(myData.zafTit)) {
                setMydata({
                    ...myData,
                    zaf: [
                        ...myData.zaf,
                        myData.zafTit
                    ]
                });
            }
        }
    };
    const marks = {
        0: {
            label: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                children: "خیلی بد"
            })
        },
        1: {
            label: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                children: "بد"
            })
        },
        2: {
            label: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                children: "معمولی"
            })
        },
        3: {
            label: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                children: "خوب"
            })
        },
        4: {
            style: {
                color: "#f50"
            },
            label: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                children: "عالی"
            })
        }
    };
    const addComent = async ()=>{
        await axios/* default.post */.Z.post(`${constans.BASE_URL}/user/comment/addComment`, myData, {
            withCredentials: true
        }).then((response)=>{
            if (response.data.success) {
                alert(response.data.message);
                setMydata({
                    rating: 0,
                    keyfiat: 0,
                    arzesh: 0,
                    noavari: 0,
                    emkanat: 0,
                    sohoolat: 0,
                    ghovTit: "",
                    zafTit: "",
                    message: "",
                    ghovat: [],
                    zaf: [],
                    productId: data._id
                });
            } else {
                alert(response.data.message);
            }
        }).catch((err)=>{
            alert(err.message);
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: user ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (product_module_default()).comenting,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "dflex jsb",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: " دیدگاه خود را بنویسید "
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "dflex acenter",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    style: {
                                        marginTop: "0px",
                                        marginBottom: "0px",
                                        marginLeft: "10px"
                                    },
                                    children: "امتیاز شما"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Product_StarRating, {
                                    initialRating: myData.rating,
                                    onRatingChange: handleRatingChange
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mt20",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (product_module_default()).range,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "کیفیت ساخت "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Slider */.iR, {
                                    value: myData.keyfiat,
                                    onAfterChange: (value)=>setMydata({
                                            ...myData,
                                            keyfiat: value
                                        }),
                                    marks: marks,
                                    step: null,
                                    defaultValue: myData.keyfiat,
                                    max: 4
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (product_module_default()).range,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "ارزش خرید به نسبت قیمت "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Slider */.iR, {
                                    value: myData.arzesh,
                                    onAfterChange: (value)=>setMydata({
                                            ...myData,
                                            arzesh: value
                                        }),
                                    marks: marks,
                                    step: null,
                                    defaultValue: myData.arzesh,
                                    max: 4
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (product_module_default()).range,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "نوآوری"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Slider */.iR, {
                                    value: myData.noavari,
                                    onAfterChange: (value)=>setMydata({
                                            ...myData,
                                            noavari: value
                                        }),
                                    marks: marks,
                                    step: null,
                                    defaultValue: myData.noavari,
                                    max: 4
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (product_module_default()).range,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "امکانات و قابلیت ها "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Slider */.iR, {
                                    value: myData.emkanat,
                                    onAfterChange: (value)=>setMydata({
                                            ...myData,
                                            emkanat: value
                                        }),
                                    marks: marks,
                                    step: null,
                                    defaultValue: myData.emkanat,
                                    max: 4
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (product_module_default()).range,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "سهولت استفاده "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Slider */.iR, {
                                    value: myData.sohoolat,
                                    onAfterChange: (value)=>setMydata({
                                            ...myData,
                                            sohoolat: value
                                        }),
                                    marks: marks,
                                    step: null,
                                    defaultValue: myData.sohoolat,
                                    max: 4
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (product_module_default()).noghat,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (product_module_default()).noghatTit,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "نقاط قوت"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (product_module_default()).noghatVal,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            value: myData.ghovTit,
                                            onChange: (e)=>setMydata({
                                                    ...myData,
                                                    ghovTit: e.target.value
                                                })
                                        }),
                                        myData.ghovTit.length > 1 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            onClick: ()=>{
                                                handleChange("ghov");
                                            },
                                            children: [
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiPlus */.poH, {})
                                            ]
                                        })
                                    ]
                                }),
                                myData.ghovat.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (product_module_default()).delNogh,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: item
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                onClick: ()=>setMydata({
                                                        ...myData,
                                                        ghovat: myData.ghovat.filter((my)=>my !== item)
                                                    }),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiPlus */.poH, {})
                                            })
                                        ]
                                    }, index))
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (product_module_default()).noghatTit,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            style: {
                                                background: "#ff9d9d"
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "نقاط ضعف"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (product_module_default()).noghatVal,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            value: myData.zafTit,
                                            onChange: (e)=>setMydata({
                                                    ...myData,
                                                    zafTit: e.target.value
                                                })
                                        }),
                                        myData.zafTit.length > 1 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            onClick: ()=>{
                                                handleChange("zaf");
                                            },
                                            children: [
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiPlus */.poH, {})
                                            ]
                                        })
                                    ]
                                }),
                                myData.zaf.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        style: {
                                            background: "#fff7f7"
                                        },
                                        className: (product_module_default()).delNogh,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    color: "#ea5d5d"
                                                },
                                                children: item
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    color: "#ea5d5d"
                                                },
                                                onClick: ()=>setItems({
                                                        ...myData,
                                                        zaf: myData.zaf.filter((my)=>my !== item)
                                                    }),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiPlus */.poH, {})
                                            })
                                        ]
                                    }, index))
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (product_module_default()).textComment,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "دیدگاه شما *"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                            value: myData.message,
                            onChange: (e)=>setMydata({
                                    ...myData,
                                    message: e.target.value
                                }),
                            children: myData.message
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: ()=>addComent(),
                            children: "ثبت"
                        })
                    ]
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (product_module_default()).comenting,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "دیدگاه خود را بنویسید"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        setViewLogin(true);
                    },
                    className: (product_module_default()).unreg,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "برای ثبت دیدگاه، لازم است ابتدا وارد حساب کاربری خود شوید. اگر این محصول را قبلا از این فروشگاه خریده باشید، دیدگاه شما به عنوان مالک محصول ثبت خواهد شد."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_index_esm/* FaRegComment */.ZvA, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "افزودن دیدگاه جدید"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Product_AddCom = (AddCom);

// EXTERNAL MODULE: ./node_modules/react-multi-date-picker/build/index.js
var build = __webpack_require__(36886);
// EXTERNAL MODULE: ./node_modules/react-date-object/calendars/persian.js
var persian = __webpack_require__(38158);
var persian_default = /*#__PURE__*/__webpack_require__.n(persian);
// EXTERNAL MODULE: ./node_modules/react-date-object/locales/persian_fa.js
var persian_fa = __webpack_require__(32193);
var persian_fa_default = /*#__PURE__*/__webpack_require__.n(persian_fa);
;// CONCATENATED MODULE: ./Components/Product/Comments.js







const Comments = ({ data  })=>{
    const date1 = new build/* DateObject */.NT(data.createdAt).convert((persian_default()), (persian_fa_default()));
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).allComments,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).allHead,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "نقد و بررسی ها"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: data.length
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "dflex acenter jcenter fn20",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsSortDown */.A89, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (product_module_default()).activeList,
                                children: "جدیدترین"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "مفید ترین"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (product_module_default()).allCont,
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    children: data && data.length > 0 && data.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (product_module_default()).headSing,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsStar */.RrZ, {}),
                                                item.rate
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "defcolor fn12",
                                            children: item.name
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: (product_module_default()).tarikh,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: date1.day
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: date1.month.name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: date1.year
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "dflex acenter mt10 mb10 green",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "flex-center fn12 ml10",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiLike */.UZT, {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "fn10",
                                            children: "خرید این محصول را توصیه میکنم"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "dflex jsb w100 mt15 fn12",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "w50 dflex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "green",
                                                    children: "نقاط قوت"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                        className: (product_module_default()).ghovlist,
                                                        children: item.ghovat.map((item1, index1)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: item1
                                                            }, index1))
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "w50 dflex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "narang",
                                                    children: "نقاط قوت"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                        className: (product_module_default()).zaflist,
                                                        children: item.zaf.map((item2, index2)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: item2
                                                            }, index2))
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "fn12 defcolor",
                                    children: item.message
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: `flex-end ${(product_module_default()).mof}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "آیا این نظر برایتان مفید بود؟"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "بله"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "12"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "خیر"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "8"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }, index))
                })
            })
        ]
    });
};
/* harmony default export */ const Product_Comments = (Comments);

;// CONCATENATED MODULE: ./Components/Product/ViewPoints.js


const ViewPoints = ({ data  })=>{
    const statusMe = (data)=>{
        let b = "";
        if (data >= 0 && data <= 1) {
            b = "خیلی بد";
        } else if (data >= 1 && data <= 2) {
            b = "بد";
        } else if (data >= 2 && data <= 3) {
            b = "معمولی";
        } else if (data >= 3 && data <= 4) {
            b = "خوب";
        } else if (data >= 4 && data <= 5) {
            b = "عالی";
        }
        return b;
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).nokat,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "لطفا پیش از ارسال نظر، خلاصه قوانین زیر را مطالعه کنید:"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "فارسی بنویسید و از کیبورد فارسی استفاده کنید. بهتر است از فضای خالی (Space) بیش‌از‌حدِ معمول، شکلک یا ایموجی استفاده نکنید و از کشیدن حروف یا کلمات با صفحه‌کلید بپرهیزید."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "نظرات خود را براساس تجربه و استفاده‌ی عملی و با دقت به نکات فنی ارسال کنید؛ بدون تعصب به محصول خاص، مزایا و معایب را بازگو کنید و بهتر است از ارسال نظرات چندکلمه‌‌ای خودداری کنید."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "بهتر است در نظرات خود از تمرکز روی عناصر متغیر مثل قیمت، پرهیز کنید."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "به کاربران و سایر اشخاص احترام بگذارید. پیام‌هایی که شامل محتوای توهین‌آمیز و کلمات نامناسب باشند، حذف می‌شوند."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                className: (product_module_default()).ot1,
                children: [
                    "امتیاز کاربران ",
                    data.avgRate,
                    " از ",
                    data.comments.length,
                    " دیدگاه"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).point,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "کیفیت ساخت"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (product_module_default()).prog,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            style: {
                                                width: `${data.avgKeyfiat / 5 * 100}%`
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (product_module_default()).progT,
                                        children: statusMe(data.avgKeyfiat)
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "ارزش خرید به نسبت قیمت"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (product_module_default()).prog,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            style: {
                                                width: `${data.avgArzesh / 5 * 100}%`
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (product_module_default()).progT,
                                        children: statusMe(data.avgArzesh)
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "نوآوری"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (product_module_default()).prog,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            style: {
                                                width: `${data.avgNoavari / 5 * 100}%`
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (product_module_default()).progT,
                                        children: statusMe(data.avgNoavari)
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "امکانات و قابلیت ها"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (product_module_default()).prog,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            style: {
                                                width: `${data.avgEmkanat / 5 * 100}%`
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (product_module_default()).progT,
                                        children: statusMe(data.avgEmkanat)
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "سهولت استفاده"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (product_module_default()).prog,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            style: {
                                                width: `${data.avgSohoolat / 5 * 100}%`
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (product_module_default()).progT,
                                        children: statusMe(data.avgSohoolat)
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_ViewPoints = (ViewPoints);

;// CONCATENATED MODULE: ./Components/Product/CommentUsers.js







const CommentUsers = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).tozihat,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Product_Heading, {
                title: "نظرات کاربران",
                icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiMessageSquareDetail */.kK8, {}),
                e_name: data.e_name
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).contCom,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Product_ViewPoints, {
                        data: data
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Product_AddCom, {
                        data: data
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Product_Comments, {
                        data: data.comments
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_CommentUsers = (CommentUsers);

// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var io_index_esm = __webpack_require__(85780);
;// CONCATENATED MODULE: ./Components/Product/Moshakhasat.js





const Moshakhasat = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).tozihat,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Product_Heading, {
                title: "مشخصات کلی",
                icon: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsTable */.VEC, {}),
                e_name: data.e_name
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (product_module_default()).moshCant,
                children: data.technicalSpecifications.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (product_module_default()).spGroup,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (product_module_default()).spgTit,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(io_index_esm/* IoIosArrowDropleft */.EY6, {})
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: item.title
                                    })
                                ]
                            }),
                            item.specs.map((item1, index1)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (product_module_default()).spgDes,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: item1.key
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: item1.value
                                        })
                                    ]
                                }, index1))
                        ]
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const Product_Moshakhasat = (Moshakhasat);

// EXTERNAL MODULE: ./node_modules/react-circular-progressbar/dist/index.js
var dist = __webpack_require__(30311);
;// CONCATENATED MODULE: ./Components/Product/Naghd.js





const Naghd = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).tozihat,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Product_Heading, {
                title: "نقد و بررسی",
                icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiTask */.ybL, {}),
                e_name: data.e_name
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).contNa,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (product_module_default()).itemNaghd,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* CircularProgressbar */.Ip, {
                                    value: data.avgKeyfiat / 5 * 100,
                                    text: `${data.avgKeyfiat / 5 * 10}`
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "کیفیت ساخت"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "از 10 امتیاز"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (product_module_default()).itemNaghd,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* CircularProgressbar */.Ip, {
                                    value: data.avgArzesh / 5 * 100,
                                    text: `${data.avgArzesh / 5 * 10}`
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "ارزش خرید به نسبت قیمت"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "از 10 امتیاز"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (product_module_default()).itemNaghd,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* CircularProgressbar */.Ip, {
                                    value: data.avgNoavari / 5 * 100,
                                    text: `${data.avgNoavari / 5 * 10}`
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "نوآوری"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "از 10 امتیاز"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (product_module_default()).itemNaghd,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* CircularProgressbar */.Ip, {
                                    value: data.avgEmkanat / 5 * 100,
                                    text: `${data.avgEmkanat / 5 * 10}`
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "امکانات و قابلیت ها"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "از 10 امتیاز"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (product_module_default()).itemNaghd,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* CircularProgressbar */.Ip, {
                                    value: data.avgSohoolat / 5 * 100,
                                    text: `${data.avgSohoolat / 5 * 10}`
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "سهولت استفاده"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "از 10 امتیاز"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_Naghd = (Naghd);

// EXTERNAL MODULE: ./node_modules/react-icons/md/index.esm.js
var md_index_esm = __webpack_require__(64348);
;// CONCATENATED MODULE: ./Components/Product/AddPor.js
/* __next_internal_client_entry_do_not_use__ default auto */ 









const AddPor = ({ data  })=>{
    const [message, setMessage] = (0,react_.useState)("");
    const { user  } = (0,react_.useContext)(AuthContext.AuthContext);
    const [loading, setLoading] = (0,react_.useState)(false);
    const [messages, setmessages] = (0,react_.useState)([]);
    const date1 = new build/* DateObject */.NT(data.createdAt).convert((persian_default()), (persian_fa_default()));
    const Send = async ()=>{
        setLoading(true);
        if (!user) {
            alert("لطفا وارد شوید");
            setLoading(false);
            return;
        }
        const data1 = {
            message,
            productId: data
        };
        await axios/* default.post */.Z.post(`${constans.BASE_URL}/user/comment/addQuestion`, data1, {
            withCredentials: true
        }).then((response)=>{
            if (response.data.success) {
                alert(response.data.message);
            } else {
                alert(response.data.message);
            }
        }).catch((err)=>{
            alert(err.message);
        });
        setLoading(false);
    };
    const getMessages = async ()=>{
        setLoading(true);
        await axios/* default.post */.Z.post(`${constans.BASE_URL}/user/comment/getQuestionsById`, {
            productId: data
        }).then((res)=>{
            if (res.data.success) {
                setmessages(res.data.data);
            } else {
                alert(res.data.message);
            }
        }).catch((err)=>{
            alert(err.message);
        });
        setLoading(false);
    };
    (0,react_.useEffect)(()=>{
        getMessages();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: loading ? /*#__PURE__*/ jsx_runtime_.jsx(SmallLoad/* default */.Z, {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                messages.length > 0 && messages.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (product_module_default()).itemPor,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (product_module_default()).headPor,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: item.name
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (product_module_default()).tarPor,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: date1.day
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: date1.month.name
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: date1.year
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "fn12 defcolor",
                                    children: item.message
                                })
                            }),
                            item.responseMessage.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (product_module_default()).pas,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "پاسخ"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "fn12 defcolor",
                                        children: item.responseMessage
                                    })
                                ]
                            })
                        ]
                    }, index)),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mt20 w100 prelative",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `${(product_module_default()).headPorAdd} w100`,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "ارسال پرسش"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "fn12 defcolor",
                            children: "به عنوان alirezadelbari20 وارد شده‌اید. نمایهٔ خود را ویرایش نمایید. بیرون رفتن؟ بخش‌های موردنیاز علامت‌گذاری شده‌اند *"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                            value: message,
                            onChange: (e)=>setMessage(e.target.value),
                            className: (product_module_default()).txaa
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: ()=>Send(),
                            className: (product_module_default()).btss,
                            children: "ارسال پرسش"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Product_AddPor = (AddPor);

;// CONCATENATED MODULE: ./Components/Product/Porsesh.js





const Porsesh = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).tozihat,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Product_Heading, {
                title: "پرسش و پاسخ",
                icon: /*#__PURE__*/ jsx_runtime_.jsx(md_index_esm/* MdOutlineHelpCenter */.MGl, {}),
                e_name: data.e_name
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (product_module_default()).contPor,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Product_AddPor, {
                    data: data._id
                })
            })
        ]
    });
};
/* harmony default export */ const Product_Porsesh = (Porsesh);

;// CONCATENATED MODULE: ./Components/Product/Tozihat.js




const Tozihat = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).tozihat,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Product_Heading, {
                title: "نقد و بررسی اجمالی",
                icon: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsPen */.bBN, {}),
                e_name: data.e_name
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (product_module_default()).desprod,
                children: data.description
            })
        ]
    });
};
/* harmony default export */ const Product_Tozihat = (Tozihat);

;// CONCATENATED MODULE: ./Components/Product/Details.js
/* __next_internal_client_entry_do_not_use__ default auto */ 







const Details = ({ data  })=>{
    const [active, setActive] = (0,react_.useState)({
        name: "توضیحات",
        comp: /*#__PURE__*/ jsx_runtime_.jsx(Product_Tozihat, {
            data: data
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).detHead,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: `${active.name === "توضیحات" && (product_module_default()).activeMosh}`,
                        onClick: ()=>setActive({
                                name: "توضیحات",
                                comp: /*#__PURE__*/ jsx_runtime_.jsx(Product_Tozihat, {
                                    data: data
                                })
                            }),
                        children: "توضیحات"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: `${active.name === "مشخصات" && (product_module_default()).activeMosh}`,
                        onClick: ()=>setActive({
                                name: "مشخصات",
                                comp: /*#__PURE__*/ jsx_runtime_.jsx(Product_Moshakhasat, {
                                    data: data
                                })
                            }),
                        children: "مشخصات"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: `${active.name === "نظرات کاربران" && (product_module_default()).activeMosh}`,
                        onClick: ()=>setActive({
                                name: "نظرات کاربران",
                                comp: /*#__PURE__*/ jsx_runtime_.jsx(Product_CommentUsers, {
                                    data: data
                                })
                            }),
                        children: "نظرات کاربران"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: `${active.name === "سوالات کاربران" && (product_module_default()).activeMosh}`,
                        onClick: ()=>setActive({
                                name: "سوالات کاربران",
                                comp: /*#__PURE__*/ jsx_runtime_.jsx(Product_Porsesh, {
                                    data: data
                                })
                            }),
                        children: "سوالات کاربران"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: `${active.name === "نقد و بررسی" && (product_module_default()).activeMosh}`,
                        onClick: ()=>setActive({
                                name: "نقد و بررسی",
                                comp: /*#__PURE__*/ jsx_runtime_.jsx(Product_Naghd, {
                                    data: data
                                })
                            }),
                        children: "نقد و بررسی"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (product_module_default()).contDetail,
                children: active.comp
            })
        ]
    });
};
/* harmony default export */ const Product_Details = (Details);

;// CONCATENATED MODULE: ./Components/Product/Discription.js



const Discription = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).dess1,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).dess,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "آیا قیمت مناسب‌تری سراغ دارید؟"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mr15",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "بلی"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "\xa0 | \xa0"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "خیر"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsBell */.m32, {})
                    }),
                    "هشدار سامانه همتا: در صورت انجام معامله، از فروشنده کد فعالسازی را گرفته و حتما در حضور ایشان، دستگاه را از طریق #7777*، برای سیمکارت خود فعالسازی نمایید. آموزش تصویری در آدرس اینترنتی hmti.ir/06 امکان برگشت کالا در گروه موبایل با دلیل انصراف از خرید تنها در صورتی مورد قبول است که پلمپ کالا باز نشده باشد."
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_Discription = (Discription);

// EXTERNAL MODULE: ./node_modules/react-slick/lib/index.js
var react_slick_lib = __webpack_require__(17738);
;// CONCATENATED MODULE: ./Components/Product/Gallery.js
/* __next_internal_client_entry_do_not_use__ default auto */ 






const Gallery = ({ images  })=>{
    const [active, setActive] = (0,react_.useState)(images[0]);
    let sliderRef = (0,react_.useRef)();
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: images.length < 4 ? images.length : 4,
        slidesToScroll: 1,
        nextArrow: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}),
        prevArrow: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).contGall,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (product_module_default()).mainImg,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: `${constans.BASE_URL}${active}`,
                    alt: "Selected",
                    fill: true
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (product_module_default()).thumbImg,
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_slick_lib/* default */.Z, {
                    ref: sliderRef,
                    className: (product_module_default()).xx,
                    ...settings,
                    children: images.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            onClick: ()=>setActive(item),
                            className: (product_module_default()).conting,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `${(product_module_default()).sliImage} ${active === item && (product_module_default()).actItem}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: `${constans.BASE_URL}${item}`,
                                    fill: true,
                                    alt: ""
                                })
                            }, index)
                        }, index))
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: (product_module_default()).nador,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsInfoCircle */.Hfo, {})
                    }),
                    "گزارش نادرستی مشخصات"
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_Gallery = (Gallery);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./Components/Product/Navbar.js



const Navbar = ({ data , title , id  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `${(product_module_default()).coNavbar}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            children: [
                data.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "",
                            children: [
                                item.title,
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (product_module_default()).mg,
                                    children: "/"
                                })
                            ]
                        })
                    }, index)),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "",
                        children: title
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const Product_Navbar = (Navbar);

// EXTERNAL MODULE: ./node_modules/react-icons/tb/index.esm.js
var tb_index_esm = __webpack_require__(79130);
;// CONCATENATED MODULE: ./Components/Product/ProductBookmark.js






const ProductBookmark = ({ productId  })=>{
    const { user , isLog  } = (0,react_.useContext)(AuthContext.AuthContext);
    const toggleBook = async ()=>{
        await axios/* default.post */.Z.post(`${constans.BASE_URL}/user/option/addBookmark`, {
            productId
        }, {
            withCredentials: true
        }).then((resopnse)=>{
            if (resopnse.data.success) {
                alert(resopnse.data.message);
                isLog();
            } else {
                alert(resopnse.data.message);
            }
        }).catch((err)=>{
            alert(err.message);
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: user && user.bookmarks.includes(productId) ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            style: {
                background: "#0183ff",
                color: "#fff"
            },
            onClick: ()=>toggleBook(),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsHeart */.sF8, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: " حذف از علاقه مندی ها"
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            onClick: ()=>toggleBook(),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsHeart */.sF8, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: " افزودن به علاقه مندی ها"
                })
            ]
        })
    });
};
/* harmony default export */ const Product_ProductBookmark = (ProductBookmark);

;// CONCATENATED MODULE: ./Components/Product/Others.js







const Others = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).contOther,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiTask */.ybL, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "تاریخ بروزرسانی : "
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "17"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "تیر"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "1401"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).contOther1,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsCheck2Square */.pPZ, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "موجود است"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).contOther1,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        style: {
                            color: "#bfa7a7"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsTruck */.qaI, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "ارسال از 3 روز کاری آینده"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).mogh,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbArrowsShuffle2 */.eHz, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: " مقایسه"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Product_ProductBookmark, {
                        productId: data._id
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).tabl,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (product_module_default()).tbImage,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    fill: true,
                                    alt: "",
                                    src: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2021/09/price-tag-1.png.webp"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "تضمین بهترین قیمت"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (product_module_default()).tbImage,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    fill: true,
                                    alt: "",
                                    src: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2021/09/shield-1.png.webp"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "ضمانت اصل بودن"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (product_module_default()).tbImage,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    fill: true,
                                    alt: "",
                                    src: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2021/09/delivery-truck-3.png.webp"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "تحویل اکسپرس"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (product_module_default()).tbImage,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    fill: true,
                                    alt: "",
                                    src: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2021/09/gift-2.png.webp"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "بسته بندی زیبا"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_Others = (Others);

;// CONCATENATED MODULE: ./Components/Product/Price.js
/* __next_internal_client_entry_do_not_use__ default auto */ 



const Price = ()=>{
    const { getPrice , active  } = (0,react_.useContext)(ProductContext.ProductCtx);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: active && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (product_module_default()).contPrice,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: getPrice().toLocaleString()
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: "تومان"
                })
            ]
        })
    });
};
/* harmony default export */ const Product_Price = (Price);

;// CONCATENATED MODULE: ./Components/Product/Timer.js


const Timer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).contTime,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).titSl,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "پیشنـهاد شگفت انگیـز"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "فرصت باقی مانده"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).contStr,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (product_module_default()).fgt,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "12"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "ثانیه"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "14"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "دقیقه"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "5"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "ساعت"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "روز"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_Timer = (Timer);

;// CONCATENATED MODULE: ./Components/Product/Title.js


const Title = ({ p_name , e_name  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).titProduct,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                children: p_name
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: e_name
            })
        ]
    });
};
/* harmony default export */ const Product_Title = (Title);

;// CONCATENATED MODULE: ./Components/Product/VizhAsli.js



const VizhAsli = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (product_module_default()).vizhAsl,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                children: data.map((item, index)=>{
                    return item.specs.map((item1, index1)=>{
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: item1.key
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "\xa0:\xa0"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: item1.value
                                })
                            ]
                        }, index1);
                    });
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (product_module_default()).opt,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        children: [
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx(io_index_esm/* IoIosArrowBack */.u1R, {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "بیشتر"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                ]
            })
        ]
    });
};
/* harmony default export */ const Product_VizhAsli = (VizhAsli);

;// CONCATENATED MODULE: ./Components/Product/ProductView.js
/* __next_internal_client_entry_do_not_use__ default auto */ 



















const ProductView = ({ data  })=>{
    const { initActive , active  } = (0,react_.useContext)(ProductContext.ProductCtx);
    const { addToCart , cart , addCount , loading , deleteCount  } = (0,react_.useContext)(CartContext.CartContext);
    (0,react_.useEffect)(()=>{
        initActive(data);
    }, []);
    // console.log(data)
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${(product_module_default()).productContent}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container pt5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Product_Navbar, {
                        data: data.parents,
                        title: data.p_name,
                        id: data._id
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `dflex jsb ${(product_module_default()).detail} mt20`,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Product_Timer, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Product_Gallery, {
                                        images: data.images
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Product_Title, {
                                        p_name: data.p_name,
                                        e_name: data.e_name
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Product_Cat, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Product_VizhAsli, {
                                        data: data.technicalSpecifications
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                        children: active ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Product_Price, {}),
                                                data && data.addonItem.map((item, index)=>{
                                                    if (item.title === "رنگ بندی") {
                                                        return /*#__PURE__*/ jsx_runtime_.jsx(Product_ColorComp, {
                                                            title: item.title,
                                                            value: item.specs,
                                                            index1: index
                                                        }, index);
                                                    } else {
                                                        return /*#__PURE__*/ jsx_runtime_.jsx(Product_Attr, {
                                                            title: item.title,
                                                            value: item.specs,
                                                            index1: index
                                                        }, index);
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Product_Addcart, {
                                                    data: data
                                                })
                                            ]
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx(SmallLoad/* default */.Z, {
                                            width: "100px",
                                            height: "100px"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Product_Discription, {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Product_Brands, {
                                        data: data
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Product_Others, {
                                        data: data
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container pt5 mt20",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Product_Details, {
                    data: data
                })
            })
        ]
    });
};
/* harmony default export */ const Product_ProductView = (ProductView);


/***/ }),

/***/ 19500:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page),
  "metadata": () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(35985);
;// CONCATENATED MODULE: ./Components/Product/ProductView.js

const proxy = (0,module_proxy.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\Components\Product\ProductView.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const ProductView = ((/* unused pure expression or super */ null && (__default__)));
// EXTERNAL MODULE: ./utils/constans.js
var constans = __webpack_require__(67411);
// EXTERNAL MODULE: ./node_modules/axios/dist/node/axios.cjs
var axios = __webpack_require__(36502);
var axios_default = /*#__PURE__*/__webpack_require__.n(axios);
;// CONCATENATED MODULE: ./app/product/[productId]/page.js




const metadata = {
    title: "صفحه محصول",
    description: "Generated by create next app"
};
const Product = async (props)=>{
    const data = await axios_default().post(`${constans.BASE_URL}/user/product/getProductById`, {
        id: props.params.productId
    }, {
        cache: "no-store"
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
};
/* harmony default export */ const page = (Product);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [859,956,348,780,343,318,690,325,359,411], () => (__webpack_exec__(94404)));
module.exports = __webpack_exports__;

})();