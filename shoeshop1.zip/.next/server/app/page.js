(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 61090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 19498:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(67797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(75183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(15815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(50515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52257)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\page.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7978)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\layout.js"],
'error': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23025)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\error.js"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12879)), "D:\\Project\\ShoeShopNext\\shoeshop1\\app\\loading.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\Project\\ShoeShopNext\\shoeshop1\\app\\page.js"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/page"
  

/***/ }),

/***/ 40368:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71703));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 63300));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94211));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 77566));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 47057));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 40408, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 85771));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 75613));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 20058));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 196))

/***/ }),

/***/ 85048:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 78301, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89222, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3507, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 54765, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5192, 23))

/***/ }),

/***/ 71703:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17738);
/* harmony import */ var _myslider_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8383);
/* harmony import */ var _myslider_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_myslider_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(64696);
/* harmony import */ var _utils_constans__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73385);
/* harmony import */ var _utils_constans__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_utils_constans__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* __next_internal_client_entry_do_not_use__ default auto */ 







const MySlider = ({ data  })=>{
    let sliderRef = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    const NextArr = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            onClick: ()=>sliderRef?.current?.slickPrev(),
            className: (_myslider_module_css__WEBPACK_IMPORTED_MODULE_5___default().lArr),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_6__/* .GrPrevious */ .Ugn, {})
        });
    };
    const PrevArr = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            onClick: ()=>sliderRef?.current?.slickNext(),
            className: (_myslider_module_css__WEBPACK_IMPORTED_MODULE_5___default().rArr),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_6__/* .GrNext */ .ULj, {})
        });
    };
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        nextArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NextArr, {}),
        prevArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PrevArr, {})
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_slick__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        ref: sliderRef,
        className: (_myslider_module_css__WEBPACK_IMPORTED_MODULE_5___default().xx),
        ...settings,
        children: [
            data.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_myslider_module_css__WEBPACK_IMPORTED_MODULE_5___default().mySli),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        style: {
                            boxShadow: "0px 0px 10px #d2cfcf"
                        },
                        src: `${_utils_constans__WEBPACK_IMPORTED_MODULE_3__.BASE_URL}${item.image}`,
                        fill: true,
                        alt: ""
                    })
                }, index)),
            data.length < 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_myslider_module_css__WEBPACK_IMPORTED_MODULE_5___default().mySli)} ${(_myslider_module_css__WEBPACK_IMPORTED_MODULE_5___default().emp)}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: "هنوز از سمت مدیر عکسی قرار نگرفته"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MySlider);


/***/ }),

/***/ 77566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17738);
/* harmony import */ var _category_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(88703);
/* harmony import */ var _category_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_category_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(64696);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_constans__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73385);
/* harmony import */ var _utils_constans__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_utils_constans__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* __next_internal_client_entry_do_not_use__ default auto */ 







const CategorySlider = ({ data  })=>{
    let sliderRef = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    const NextArr = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            onClick: ()=>sliderRef?.current?.slickPrev(),
            className: (_category_module_css__WEBPACK_IMPORTED_MODULE_5___default().lArr),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_6__/* .GrPrevious */ .Ugn, {})
        });
    };
    const PrevArr = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            onClick: ()=>sliderRef?.current?.slickNext(),
            className: (_category_module_css__WEBPACK_IMPORTED_MODULE_5___default().rArr),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_6__/* .GrNext */ .ULj, {})
        });
    };
    const settings = {
        dots: false,
        infinite: false,
        speed: 500,
        slidesToShow: data.length < 8 ? data.length : 8,
        slidesToScroll: 1,
        nextArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NextArr, {}),
        prevArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PrevArr, {})
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_slick__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        ref: sliderRef,
        className: (_category_module_css__WEBPACK_IMPORTED_MODULE_5___default().xx),
        ...settings,
        children: data.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_category_module_css__WEBPACK_IMPORTED_MODULE_5___default().item),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_category_module_css__WEBPACK_IMPORTED_MODULE_5___default().item1),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_category_module_css__WEBPACK_IMPORTED_MODULE_5___default().image),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: `${_utils_constans__WEBPACK_IMPORTED_MODULE_3__.BASE_URL}${item.image}`,
                                fill: true,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_category_module_css__WEBPACK_IMPORTED_MODULE_5___default().title),
                            children: item.title
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_category_module_css__WEBPACK_IMPORTED_MODULE_5___default().count),
                            children: "+10 محصول"
                        })
                    ]
                })
            }, index))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategorySlider);


/***/ }),

/***/ 94211:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ slider4_Slider4)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/react-slick/lib/index.js
var lib = __webpack_require__(17738);
// EXTERNAL MODULE: ./Components/Home/slider4/slider.module.css
var slider_module = __webpack_require__(74590);
var slider_module_default = /*#__PURE__*/__webpack_require__.n(slider_module);
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var index_esm = __webpack_require__(75484);
// EXTERNAL MODULE: ./utils/constans.js
var constans = __webpack_require__(73385);
// EXTERNAL MODULE: ./Context/AuthContext.js
var AuthContext = __webpack_require__(24980);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(40248);
// EXTERNAL MODULE: ./Components/Global/global.module.css
var global_module = __webpack_require__(71015);
var global_module_default = /*#__PURE__*/__webpack_require__.n(global_module);
;// CONCATENATED MODULE: ./Components/Global/Bookmark.js







const Bookmark = ({ productId  })=>{
    const { user , isLog , setViewLogin  } = (0,react_.useContext)(AuthContext.AuthContext);
    const toggleBook = async ()=>{
        if (user) {
            await axios/* default.post */.Z.post(`${constans.BASE_URL}/user/option/addBookmark`, {
                productId
            }, {
                withCredentials: true
            }).then((resopnse)=>{
                if (resopnse.data.success) {
                    alert(resopnse.data.message);
                    isLog();
                } else {
                    alert(resopnse.data.message);
                }
            }).catch((err)=>{
                alert(err.message);
            });
        } else {
            setViewLogin(true);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: user && user.bookmarks.includes(productId) ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
            onClick: ()=>{
                toggleBook();
            },
            className: (global_module_default()).book,
            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsFillHeartFill */.xTs, {
                color: "#fdc47a"
            })
        }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
            onClick: ()=>{
                toggleBook();
            },
            className: (global_module_default()).book,
            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsHeart */.sF8, {})
        })
    });
};
/* harmony default export */ const Global_Bookmark = (Bookmark);

// EXTERNAL MODULE: ./node_modules/react-rating/lib/react-rating.cjs.js
var react_rating_cjs = __webpack_require__(29366);
var react_rating_cjs_default = /*#__PURE__*/__webpack_require__.n(react_rating_cjs);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./Components/Home/slider4/Slider4.js
/* __next_internal_client_entry_do_not_use__ default auto */ 









const Slider4 = ({ data , data1  })=>{
    const [slids, setSlids] = (0,react_.useState)([]);
    const [cats, setCats] = (0,react_.useState)([]);
    (0,react_.useEffect)(()=>{
        let x = [];
        data1.map((item)=>{
            item.subcategories.map((item1)=>{
                if (item1.parent === null && !x.includes(JSON.stringify(item1))) {
                    x.push(JSON.stringify(item1));
                }
            });
        });
        setSlids(data1.filter((item)=>item.paName === JSON.parse(x[0]).title));
        setCats(x);
    }, []);
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: data1.length > 2 ? 2 : data1.length,
        slidesToScroll: 1,
        prevArrow: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}),
        nextArrow: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
    };
    const Changing = (id)=>{
        let x = [];
        data1.map((item)=>{
            item.subcategories.map((item1)=>{
                if (item1._id === id) {
                    x.push(item);
                }
            });
        });
        setSlids(x);
    };
    const Pricing = (props)=>{
        let priceMe = 0;
        let discountMe = 0;
        if (props.discount.type === "naghdi") {
            priceMe = parseInt(props.price);
            discountMe = parseInt(props.price) - parseInt(props.discount.value);
        } else {
            priceMe = parseInt(props.price);
            discountMe = parseInt(props.price) / 100 * parseInt(props.discount.value) - parseInt(props.price);
        }
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (slider_module_default()).price,
            children: [
                parseInt(props.discount.value) > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (slider_module_default()).khat,
                            children: parseInt(priceMe).toLocaleString()
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (slider_module_default()).disc,
                            children: parseInt(discountMe).toLocaleString()
                        })
                    ]
                }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: (slider_module_default()).disc,
                        children: parseInt(priceMe).toLocaleString()
                    })
                }),
                "\xa0",
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: (slider_module_default()).fn1,
                    children: "تومان"
                })
            ]
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (slider_module_default()).content,
        children: data1.length > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (slider_module_default()).left,
                    children: cats.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: ()=>{
                                Changing(JSON.parse(item)._id);
                            },
                            className: slids && slids.length > 0 && slids[0].paName === JSON.parse(item).title && (slider_module_default()).active,
                            children: JSON.parse(item).title
                        }, index))
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (slider_module_default()).right,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(lib/* default */.Z, {
                        className: (slider_module_default()).xx,
                        ...settings,
                        children: slids && slids.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (slider_module_default()).mySli,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: `/product/${item._id}`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (slider_module_default()).image,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: `${constans.BASE_URL}${item.images[0]}`,
                                                        fill: true,
                                                        alt: item.name
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Pricing, {
                                                    price: item.priceAsli,
                                                    discount: item.discount
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (slider_module_default()).name,
                                                    children: item.p_name
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: (slider_module_default()).icons,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsCart */.UZs, {})
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsActivity */.JqA, {})
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Global_Bookmark, {
                                                            productId: item._id
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (slider_module_default()).stars,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((react_rating_cjs_default()), {
                                                        initialRating: item.rate,
                                                        emptySymbol: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsStar */.RrZ, {
                                                            style: {
                                                                color: "gold"
                                                            }
                                                        }),
                                                        fullSymbol: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsStarFill */.kRm, {
                                                            style: {
                                                                color: "gold"
                                                            }
                                                        }),
                                                        readonly: true
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }, index))
                    })
                })
            ]
        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (slider_module_default()).emp,
            children: "محصولی موجود نیست"
        })
    });
};
/* harmony default export */ const slider4_Slider4 = (Slider4);


/***/ }),

/***/ 75613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _slider5_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(56458);
/* harmony import */ var _slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_slider5_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17738);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75484);
/* harmony import */ var _utils_constans__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73385);
/* harmony import */ var _utils_constans__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_utils_constans__WEBPACK_IMPORTED_MODULE_3__);
/* __next_internal_client_entry_do_not_use__ default auto */ 





function Slider5({ slides , data1  }) {
    // console.log(data1[0].technicalSpecifications[0].specs)
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        vertical: true,
        verticalSwiping: true,
        prevArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
        nextArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
    };
    const Pricing = (props)=>{
        let priceMe = 0;
        let discountMe = 0;
        if (props.discount.type === "naghdi") {
            priceMe = parseInt(props.price);
            discountMe = parseInt(props.price) - parseInt(props.discount.value);
        } else {
            priceMe = parseInt(props.price);
            discountMe = parseInt(props.price) / 100 * parseInt(props.discount.value) - parseInt(props.price);
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().pricing),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().price),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().khat),
                            children: parseInt(priceMe).toLocaleString()
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().disc),
                            children: parseInt(discountMe).toLocaleString()
                        }),
                        "\xa0",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().fn1),
                            children: "تومان"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().bs),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_5__/* .BsCart */ .UZs, {})
                })
            ]
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().mSl),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_slick__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            ...settings,
            className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().xx),
            children: data1.length > 0 ? data1.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().sl),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().contAsli),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().slLeft),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().save),
                                        children: [
                                            item.discount.value,
                                            "%"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().tit),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "شگفت انگیز"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().imgs),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().image),
                                            fill: true,
                                            src: `${_utils_constans__WEBPACK_IMPORTED_MODULE_3__.BASE_URL}${item.images[0]}`,
                                            alt: "s"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().slRight),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().name),
                                        children: item.p_name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().vizh),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            children: item.technicalSpecifications.map((item, index)=>{
                                                return item.specs.map((item1, index1)=>{
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: item1.key
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: ":"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: item1.value
                                                            })
                                                        ]
                                                    }, index1);
                                                });
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Pricing, {
                                        price: item.priceAsli,
                                        discount: item.discount
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().timer)
                                    })
                                ]
                            })
                        ]
                    })
                }, index)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().sl),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_slider5_module_css__WEBPACK_IMPORTED_MODULE_4___default().contAsli),
                    children: "محصولی موجود نیست"
                })
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Slider5);


/***/ }),

/***/ 47057:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ slider6_Slider6)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./Components/Home/slider6/slider.module.css
var slider_module = __webpack_require__(61715);
var slider_module_default = /*#__PURE__*/__webpack_require__.n(slider_module);
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var index_esm = __webpack_require__(75484);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var io_index_esm = __webpack_require__(85780);
// EXTERNAL MODULE: ./node_modules/react-slick/lib/index.js
var lib = __webpack_require__(17738);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./utils/constans.js
var constans = __webpack_require__(73385);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./Components/Home/slider6/ItemComp.js






const ItemComp = ({ data , index  })=>{
    const Pricing = (props)=>{
        let priceMe = 0;
        let discountMe = 0;
        if (props.discount.type === "naghdi") {
            priceMe = parseInt(props.price);
            discountMe = parseInt(props.price) - parseInt(props.discount.value);
        } else {
            priceMe = parseInt(props.price);
            discountMe = parseInt(props.price) / 100 * parseInt(props.discount.value) - parseInt(props.price);
        }
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (slider_module_default()).price,
            children: [
                parseInt(props.discount.value) > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (slider_module_default()).khat,
                            children: parseInt(priceMe).toLocaleString()
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (slider_module_default()).disc,
                            children: parseInt(discountMe).toLocaleString()
                        })
                    ]
                }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: (slider_module_default()).disc,
                        children: parseInt(priceMe).toLocaleString()
                    })
                }),
                "\xa0",
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: (slider_module_default()).fn1,
                    children: "تومان"
                })
            ]
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: `/product/${data._id}`,
        className: (slider_module_default()).item,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (slider_module_default()).image,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: `${constans.BASE_URL}${data.images[0]}`,
                        fill: true,
                        alt: ""
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (slider_module_default()).name,
                    children: data.p_name
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (slider_module_default()).footer,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Pricing, {
                            price: data.priceAsli,
                            discount: data.discount
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (slider_module_default()).rft,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsPlusLg */.B8K, {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (slider_module_default()).itFooter,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (slider_module_default()).l2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsHeart */.sF8, {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsArrowLeftRight */.Dgg, {})
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (slider_module_default()).r2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "افزودن به سبد "
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsCart */.UZs, {})
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }, index);
};
/* harmony default export */ const slider6_ItemComp = (ItemComp);

;// CONCATENATED MODULE: ./Components/Home/slider6/Slider6.js
/* __next_internal_client_entry_do_not_use__ default auto */ 






const Slider6 = ({ data  })=>{
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: data.length > 5 ? 5 : data.length,
        slidesToScroll: 2,
        prevArrow: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}),
        nextArrow: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (slider_module_default()).header,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (slider_module_default()).titHead,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsCartPlus */.RFG, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "جدید ترین محصولات"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (slider_module_default()).btn,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(io_index_esm/* IoIosArrowBack */.u1R, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "مشاهده همه"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(lib/* default */.Z, {
                    className: (slider_module_default()).xx,
                    ...settings,
                    children: data.length > 0 && data.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(slider6_ItemComp, {
                            data: item,
                            index: index
                        }, index))
                })
            })
        ]
    });
};
/* harmony default export */ const slider6_Slider6 = (Slider6);


/***/ }),

/***/ 20058:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ slider7_Slider7)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./Components/Home/slider7/slider.module.css
var slider_module = __webpack_require__(89692);
var slider_module_default = /*#__PURE__*/__webpack_require__.n(slider_module);
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var index_esm = __webpack_require__(75484);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./Components/Home/slider7/ItemComp.js





const ItemComp = ({ data , index  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (slider_module_default()).item,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (slider_module_default()).imaging,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: data.image,
                    fill: true,
                    alt: ""
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (slider_module_default()).lefting,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: (slider_module_default()).number,
                        children: index + 1
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        children: data.name
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (slider_module_default()).footing,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (slider_module_default()).price,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (slider_module_default()).khat,
                                        children: parseInt(1200000).toLocaleString()
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (slider_module_default()).disc,
                                        children: parseInt(1800000).toLocaleString()
                                    }),
                                    "\xa0",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (slider_module_default()).fn1,
                                        children: "تومان"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (slider_module_default()).star,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: data.rate
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsStar */.RrZ, {})
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    }, index);
};
/* harmony default export */ const slider7_ItemComp = (ItemComp);

;// CONCATENATED MODULE: ./Components/Home/slider7/Slider7.js
/* __next_internal_client_entry_do_not_use__ default auto */ 




const Slider7 = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (slider_module_default()).header,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (slider_module_default()).titHead,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsArchive */.RXM, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "محصولات پرفروش"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (slider_module_default()).conting,
                children: data.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(slider7_ItemComp, {
                        data: item,
                        index: index
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const slider7_Slider7 = (Slider7);


/***/ }),

/***/ 196:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ slider8_Slider8)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./Components/Home/slider8/slider.module.css
var slider_module = __webpack_require__(56411);
var slider_module_default = /*#__PURE__*/__webpack_require__.n(slider_module);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(85780);
// EXTERNAL MODULE: ./node_modules/react-slick/lib/index.js
var lib = __webpack_require__(17738);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./utils/constans.js
var constans = __webpack_require__(73385);
// EXTERNAL MODULE: ./node_modules/react-multi-date-picker/build/index.js
var build = __webpack_require__(36886);
// EXTERNAL MODULE: ./node_modules/react-date-object/calendars/persian.js
var persian = __webpack_require__(38158);
var persian_default = /*#__PURE__*/__webpack_require__.n(persian);
// EXTERNAL MODULE: ./node_modules/react-date-object/locales/persian_fa.js
var persian_fa = __webpack_require__(32193);
var persian_fa_default = /*#__PURE__*/__webpack_require__.n(persian_fa);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./Components/Home/slider8/ItemComp.js








const ItemComp = ({ data , index  })=>{
    const date1 = new build/* DateObject */.NT(data.createdAt).convert((persian_default()), (persian_fa_default()));
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: `/article/${data._id}`,
        className: (slider_module_default()).item,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (slider_module_default()).image,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: `${constans.BASE_URL}${data.image}`,
                        fill: true,
                        alt: ""
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (slider_module_default()).name,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: date1.day
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: date1.month.name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: date1.year
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: data.title
                        })
                    ]
                })
            ]
        })
    }, index);
};
/* harmony default export */ const slider8_ItemComp = (ItemComp);

// EXTERNAL MODULE: ./node_modules/react-icons/tfi/index.esm.js
var tfi_index_esm = __webpack_require__(2537);
;// CONCATENATED MODULE: ./Components/Home/slider8/Slider8.js
/* __next_internal_client_entry_do_not_use__ default auto */ 





const Slider8 = ({ data  })=>{
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 2,
        prevArrow: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}),
        nextArrow: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (slider_module_default()).header,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (slider_module_default()).titHead,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(tfi_index_esm/* TfiRssAlt */.y4, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "دانش نامه"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (slider_module_default()).btn,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* IoIosArrowBack */.u1R, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "مشاهده همه"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(lib/* default */.Z, {
                    className: (slider_module_default()).xx,
                    ...settings,
                    children: data.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(slider8_ItemComp, {
                            data: item,
                            index: index
                        }, index))
                })
            })
        ]
    });
};
/* harmony default export */ const slider8_Slider8 = (Slider8);


/***/ }),

/***/ 63300:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _carousel_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(19170);
/* harmony import */ var _carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_carousel_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17738);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(64696);
/* harmony import */ var _utils_constans__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73385);
/* harmony import */ var _utils_constans__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_utils_constans__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* __next_internal_client_entry_do_not_use__ default auto */ 








const Carousel = ({ data  })=>{
    let sliderRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)();
    const Pricing = (props)=>{
        let priceMe = 0;
        let discountMe = 0;
        if (props.discount.type === "naghdi") {
            priceMe = parseInt(props.price);
            discountMe = parseInt(props.price) - parseInt(props.discount.value);
        } else {
            priceMe = parseInt(props.price);
            discountMe = parseInt(props.price) / 100 * parseInt(props.discount.value) - parseInt(props.price);
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().price),
            children: [
                parseInt(props.discount.value) > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().khat),
                            children: parseInt(priceMe).toLocaleString()
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().disc),
                            children: parseInt(discountMe).toLocaleString()
                        })
                    ]
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().disc),
                        children: parseInt(priceMe).toLocaleString()
                    })
                }),
                "\xa0",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().fn1),
                    children: "تومان"
                })
            ]
        });
    };
    const NextArr = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            onClick: ()=>sliderRef?.current?.slickPrev(),
            className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().lArr),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_7__/* .GrPrevious */ .Ugn, {})
        });
    };
    const PrevArr = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            onClick: ()=>sliderRef?.current?.slickNext(),
            className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().rArr),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_7__/* .GrNext */ .ULj, {})
        });
    };
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        nextArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NextArr, {}),
        prevArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PrevArr, {})
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_slick__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        ref: sliderRef,
        className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().xx),
        ...settings,
        children: data.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                href: `/product/${item._id}`,
                className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().mySli),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().imgSty),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            src: `${_utils_constans__WEBPACK_IMPORTED_MODULE_3__.BASE_URL}${item.images[0]}`,
                            fill: true,
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: (_carousel_module_css__WEBPACK_IMPORTED_MODULE_6___default().title),
                        children: item.p_name
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Pricing, {
                        price: item.priceAsli,
                        discount: item.discount
                    })
                ]
            }, index))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Carousel);


/***/ }),

/***/ 85771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_timer_hook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48154);
/* harmony import */ var react_timer_hook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_timer_hook__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _takhfif_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97012);
/* harmony import */ var _takhfif_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_takhfif_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ default auto */ 


function Timer() {
    //   const expiryTimestamp = new Date('October 1, 2021 00:00:00');
    const expiryTimestamp = new Date("2023/06/24");
    const { seconds , minutes , hours , days , isRunning , start , pause , resume , restart  } = (0,react_timer_hook__WEBPACK_IMPORTED_MODULE_1__.useTimer)({
        expiryTimestamp,
        onExpire: ()=>console.warn("onExpire called")
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_takhfif_module_css__WEBPACK_IMPORTED_MODULE_2___default().contTimer),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_takhfif_module_css__WEBPACK_IMPORTED_MODULE_2___default().cyel),
                        children: seconds
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "ثانیه"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: minutes
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "دقیقه"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: hours
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "ساعت"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: days
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "روز"
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Timer);
{}

/***/ }),

/***/ 8383:
/***/ ((module) => {

// Exports
module.exports = {
	"xx": "myslider_xx__fFAeE",
	"mySli": "myslider_mySli__fPB8K",
	"lArr": "myslider_lArr__y5Xrx",
	"rArr": "myslider_rArr__JAdUu",
	"emp": "myslider_emp__r7lwi"
};


/***/ }),

/***/ 88703:
/***/ ((module) => {

// Exports
module.exports = {
	"item": "category_item__KYqna",
	"item1": "category_item1__QqMjd",
	"title": "category_title__QPKQa",
	"image": "category_image__L_9q8",
	"count": "category_count__dT359",
	"lArr": "category_lArr__ZC1yM",
	"rArr": "category_rArr__MCENQ"
};


/***/ }),

/***/ 74590:
/***/ ((module) => {

// Exports
module.exports = {
	"content": "slider_content___ktJv",
	"left": "slider_left__P0nnH",
	"active": "slider_active__M55nG",
	"xx": "slider_xx__ocoC5",
	"right": "slider_right__HeqbP",
	"mySli": "slider_mySli__obCyh",
	"price": "slider_price__ScCWf",
	"disc": "slider_disc__1x1I4",
	"fn1": "slider_fn1__xOOeE",
	"khat": "slider_khat__c1uCf",
	"image": "slider_image__qUabt",
	"name": "slider_name__jjdcY",
	"icons": "slider_icons__xcncS",
	"stars": "slider_stars__q3q_5",
	"emp": "slider_emp__oJ0Fz"
};


/***/ }),

/***/ 56458:
/***/ ((module) => {

// Exports
module.exports = {
	"xx": "slider5_xx__GtDs_",
	"contAsli": "slider5_contAsli__vQP0D",
	"save": "slider5_save__Ss678",
	"tit": "slider5_tit__2NzI6",
	"slLeft": "slider5_slLeft__jJIGy",
	"imgs": "slider5_imgs__uRG7J",
	"slRight": "slider5_slRight__GHZjR",
	"name": "slider5_name__LqI_f",
	"vizh": "slider5_vizh__XhzX2",
	"pricing": "slider5_pricing__NIPSK",
	"price": "slider5_price__jsjND",
	"disc": "slider5_disc__NYPuh",
	"fn1": "slider5_fn1__V2Atf",
	"khat": "slider5_khat__kuUby",
	"bs": "slider5_bs__rNPD8",
	"contTimer": "slider5_contTimer__KBRLb",
	"timer": "slider5_timer__PujgH",
	"mSl": "slider5_mSl__xBAP0",
	"sl": "slider5_sl__VgH6o",
	"emp": "slider5_emp__FrN24"
};


/***/ }),

/***/ 61715:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "slider_header__X8t0f",
	"titHead": "slider_titHead__vsr1F",
	"btn": "slider_btn__Y3g6C",
	"item": "slider_item__0v8Jn",
	"xx": "slider_xx___kRoP",
	"image": "slider_image__9ciwG",
	"name": "slider_name__pZ5iS",
	"price": "slider_price__GfyDe",
	"disc": "slider_disc__Vjxbk",
	"fn1": "slider_fn1__gbPc7",
	"khat": "slider_khat__lWO_C",
	"footer": "slider_footer__mtMLb",
	"rft": "slider_rft__Y03Ga",
	"itFooter": "slider_itFooter__OYtcK",
	"r2": "slider_r2__Qt3ra",
	"l2": "slider_l2__GTOZL"
};


/***/ }),

/***/ 89692:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "slider_header__f2AFO",
	"titHead": "slider_titHead__XWlof",
	"btn": "slider_btn__juxj2",
	"price": "slider_price__zyaW3",
	"disc": "slider_disc__KK1Jp",
	"fn1": "slider_fn1__WWSPb",
	"khat": "slider_khat__wGdEs",
	"conting": "slider_conting__6xDpp",
	"item": "slider_item__HVjuz",
	"imaging": "slider_imaging__KuBei",
	"number": "slider_number__mbvMq",
	"lefting": "slider_lefting__nHJ8O",
	"footing": "slider_footing__EVZYH",
	"star": "slider_star__i0IiH"
};


/***/ }),

/***/ 56411:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "slider_header__m1cAL",
	"titHead": "slider_titHead__mFF6U",
	"btn": "slider_btn___IWvv",
	"item": "slider_item__wZb4i",
	"xx": "slider_xx__MujDz",
	"image": "slider_image__EtkQp",
	"name": "slider_name__hLodT"
};


/***/ }),

/***/ 19170:
/***/ ((module) => {

// Exports
module.exports = {
	"xx": "carousel_xx__PG2tW",
	"imgSty": "carousel_imgSty__CcjtW",
	"title": "carousel_title___htNd",
	"price": "carousel_price__jQ8BT",
	"disc": "carousel_disc__T3Lyq",
	"fn1": "carousel_fn1__eEyk8",
	"khat": "carousel_khat__rpjPP",
	"rArr": "carousel_rArr__xnzE_",
	"lArr": "carousel_lArr__oL39Y",
	"mySli": "carousel_mySli__F8Wva"
};


/***/ }),

/***/ 75692:
/***/ ((module) => {

// Exports
module.exports = {
	"cont": "slider_cont__BrRIC",
	"head": "slider_head__SaqMl",
	"slider": "slider_slider__38MeR"
};


/***/ }),

/***/ 41688:
/***/ ((module) => {

// Exports
module.exports = {
	"cont": "tabligh_cont__k_VXu",
	"bst": "tabligh_bst__rlHj0"
};


/***/ }),

/***/ 97012:
/***/ ((module) => {

// Exports
module.exports = {
	"cont": "takhfif_cont__vUJT8",
	"img": "takhfif_img__ReZbq",
	"contRight": "takhfif_contRight__tTZDo",
	"tc": "takhfif_tc__Gdmia",
	"tx1": "takhfif_tx1__cJCup",
	"contLeft": "takhfif_contLeft__7GhgR",
	"tkh": "takhfif_tkh__aLvPo",
	"contTimer": "takhfif_contTimer___sPR8",
	"cyel": "takhfif_cyel__yOHij"
};


/***/ }),

/***/ 29951:
/***/ ((module) => {

// Exports
module.exports = {
	"cont": "takhfif_cont__vUJT8",
	"img": "takhfif_img__ReZbq",
	"contRight": "takhfif_contRight__tTZDo",
	"tc": "takhfif_tc__Gdmia",
	"tx1": "takhfif_tx1__cJCup",
	"contLeft": "takhfif_contLeft__7GhgR",
	"tkh": "takhfif_tkh__aLvPo",
	"contTimer": "takhfif_contTimer___sPR8",
	"cyel": "takhfif_cyel__yOHij"
};


/***/ }),

/***/ 52257:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "metadata": () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(35985);
;// CONCATENATED MODULE: ./Components/Home/MySlider/MySlider.js

const proxy = (0,module_proxy.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\Components\Home\MySlider\MySlider.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const MySlider = (__default__);
;// CONCATENATED MODULE: ./Components/Home/sliderTopLeft/Carousel.js

const Carousel_proxy = (0,module_proxy.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\Components\Home\sliderTopLeft\Carousel.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Carousel_esModule, $$typeof: Carousel_$$typeof } = Carousel_proxy;
const Carousel_default_ = Carousel_proxy.default;


/* harmony default export */ const Carousel = (Carousel_default_);
// EXTERNAL MODULE: ./Components/Home/sliderTopLeft/slider.module.css
var slider_module = __webpack_require__(75692);
var slider_module_default = /*#__PURE__*/__webpack_require__.n(slider_module);
;// CONCATENATED MODULE: ./Components/Home/sliderTopLeft/Slider.js



const SliderLeft = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (slider_module_default()).cont,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (slider_module_default()).head,
                children: "پیشنهاد لحظه ای"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (slider_module_default()).slider,
                children: data.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx(Carousel, {
                    data: data
                }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    style: {
                        textAlign: "center",
                        color: "#888"
                    },
                    children: "محصولی موجود نیست"
                })
            })
        ]
    });
};
/* harmony default export */ const Slider = (SliderLeft);

// EXTERNAL MODULE: ./utils/constans.js
var constans = __webpack_require__(67411);
;// CONCATENATED MODULE: ./Components/Home/categorySlider/CategorySlider.js

const CategorySlider_proxy = (0,module_proxy.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\Components\Home\categorySlider\CategorySlider.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: CategorySlider_esModule, $$typeof: CategorySlider_$$typeof } = CategorySlider_proxy;
const CategorySlider_default_ = CategorySlider_proxy.default;


/* harmony default export */ const CategorySlider = (CategorySlider_default_);
;// CONCATENATED MODULE: ./Components/Home/slider4/Slider4.js

const Slider4_proxy = (0,module_proxy.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\Components\Home\slider4\Slider4.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Slider4_esModule, $$typeof: Slider4_$$typeof } = Slider4_proxy;
const Slider4_default_ = Slider4_proxy.default;


/* harmony default export */ const Slider4 = (Slider4_default_);
;// CONCATENATED MODULE: ./Components/Home/slider5/Slider5.js

const Slider5_proxy = (0,module_proxy.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\Components\Home\slider5\Slider5.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Slider5_esModule, $$typeof: Slider5_$$typeof } = Slider5_proxy;
const Slider5_default_ = Slider5_proxy.default;


/* harmony default export */ const Slider5 = (Slider5_default_);
;// CONCATENATED MODULE: ./Components/Home/slider6/Slider6.js

const Slider6_proxy = (0,module_proxy.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\Components\Home\slider6\Slider6.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Slider6_esModule, $$typeof: Slider6_$$typeof } = Slider6_proxy;
const Slider6_default_ = Slider6_proxy.default;


/* harmony default export */ const Slider6 = (Slider6_default_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(62208);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./Components/Home/takhfif/takhfif.module.css
var takhfif_module = __webpack_require__(29951);
var takhfif_module_default = /*#__PURE__*/__webpack_require__.n(takhfif_module);
;// CONCATENATED MODULE: ./Components/Home/takhfif/Timer.js

const Timer_proxy = (0,module_proxy.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\Components\Home\takhfif\Timer.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Timer_esModule, $$typeof: Timer_$$typeof } = Timer_proxy;
const Timer_default_ = Timer_proxy.default;


/* harmony default export */ const Timer = ((/* unused pure expression or super */ null && (Timer_default_)));
;// CONCATENATED MODULE: ./Components/Home/takhfif/Takhfif.js




const Takhfif = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (takhfif_module_default()).cont,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (takhfif_module_default()).contRight,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (takhfif_module_default()).img,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            fill: true,
                            src: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2023/03/spring1402.png",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                className: (takhfif_module_default()).tx1,
                                children: [
                                    "تخفیف عیدانه همه محصولات",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (takhfif_module_default()).tc,
                                        children: "44"
                                    }),
                                    "٪ تخفیف"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (takhfif_module_default()).contLeft,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "وضعیت"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "فعال"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: (takhfif_module_default()).tkh,
                        children: "cristian"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const takhfif_Takhfif = (Takhfif);

// EXTERNAL MODULE: ./Components/Home/tabligh/tabligh.module.css
var tabligh_module = __webpack_require__(41688);
var tabligh_module_default = /*#__PURE__*/__webpack_require__.n(tabligh_module);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(22149);
;// CONCATENATED MODULE: ./Components/Home/tabligh/Tabligh.js



const Tabligh = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (tabligh_module_default()).cont,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    children: "انواع موبایل و تبلت"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "از معتبر ترین برند های جهان"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "مشاهده و خرید"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (tabligh_module_default()).bst,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* IoIosArrowBack */.u1R, {})
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const tabligh_Tabligh = (Tabligh);

;// CONCATENATED MODULE: ./Components/Home/slider7/Slider7.js

const Slider7_proxy = (0,module_proxy.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\Components\Home\slider7\Slider7.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Slider7_esModule, $$typeof: Slider7_$$typeof } = Slider7_proxy;
const Slider7_default_ = Slider7_proxy.default;


/* harmony default export */ const Slider7 = (Slider7_default_);
;// CONCATENATED MODULE: ./Components/Home/slider8/Slider8.js

const Slider8_proxy = (0,module_proxy.createProxy)(String.raw`D:\Project\ShoeShopNext\shoeshop1\Components\Home\slider8\Slider8.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Slider8_esModule, $$typeof: Slider8_$$typeof } = Slider8_proxy;
const Slider8_default_ = Slider8_proxy.default;


/* harmony default export */ const Slider8 = (Slider8_default_);
;// CONCATENATED MODULE: ./app/page.js












const metadata = {
    title: "فروشگاه دلبر شاپ",
    description: "Generated by create next app"
};
async function Home(props) {
    const res = await fetch(`${constans.BASE_URL}/user/option/getHome`, {
        headers: {
            "Content-Type": "application/json"
        },
        cache: "no-store",
        method: "GET"
    });
    const data = await res.json();
    const mostSale = [
        {
            id: 1,
            name: "تلويزيون ال اي دي هوشمند سامسونگ مدل 55KU7970 سايز 55 اينچ",
            image: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2017/10/1-32-75x75.jpg",
            price: 850000,
            discount: 0,
            rate: 4.5
        },
        {
            id: 2,
            name: "کوله پشتی کينگ کمپ مدل Peach 28",
            image: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2018/06/01-75x75.png",
            price: 246500,
            discount: 0,
            rate: 4.0
        },
        {
            id: 3,
            name: "گوشی موبایل اپل مدل iPhone 12 A2404 دو سیم‌ کارت ظرفیت 128 گیگابایت",
            image: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2019/03/aplle-75x75.webp",
            price: 430000,
            discount: 0,
            rate: 4.5
        },
        {
            id: 4,
            name: "تلويزيون ال اي دي هوشمند سامسونگ مدل 55KU7970 سايز 55 اينچ",
            image: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2017/10/1-32-75x75.jpg",
            price: 850000,
            discount: 0,
            rate: 4.5
        },
        {
            id: 5,
            name: "کوله پشتی کينگ کمپ مدل Peach 28",
            image: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2018/06/01-75x75.png",
            price: 246500,
            discount: 0,
            rate: 4.0
        },
        {
            id: 6,
            name: "گوشی موبایل اپل مدل iPhone 12 A2404 دو سیم‌ کارت ظرفیت 128 گیگابایت",
            image: "https://demos.mahdisweb.net/digiland/wp-content/uploads/2019/03/aplle-75x75.webp",
            price: 430000,
            discount: 0,
            rate: 4.5
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "container",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "compRight",
                        children: data && /*#__PURE__*/ jsx_runtime_.jsx(MySlider, {
                            data: data.data.SliderTop
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "compLeft",
                        children: data && /*#__PURE__*/ jsx_runtime_.jsx(Slider, {
                            data: data.data.SliderMoment
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "catslider",
                children: data && /*#__PURE__*/ jsx_runtime_.jsx(CategorySlider, {
                    data: data.data.Categorys
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "centersec",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "sec3Right",
                        children: data && /*#__PURE__*/ jsx_runtime_.jsx(Slider4, {
                            data1: data.data.ProSlider
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "sec3Left",
                        children: data && /*#__PURE__*/ jsx_runtime_.jsx(Slider5, {
                            data1: data.data.ShegeftSlider
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "sec4",
                children: data && /*#__PURE__*/ jsx_runtime_.jsx(Slider6, {
                    data: data.data.NewsProduct
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "sec5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(takhfif_Takhfif, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(tabligh_Tabligh, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "sec6",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Slider7, {
                    data: mostSale
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "sec7",
                children: data && /*#__PURE__*/ jsx_runtime_.jsx(Slider8, {
                    data: data.data.SliderArticle
                })
            })
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [859,943,978,780,343,162,731,222,411], () => (__webpack_exec__(19498)));
module.exports = __webpack_exports__;

})();