import AslLoad from "@/Components/Global/AslLoad"

const Loading = () => {
  return (
    <AslLoad />
  )
}

export default Loading