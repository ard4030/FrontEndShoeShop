import OrdersView from '@/Components/Panel/OrdersView'
import React from 'react'

const Orders = () => {
  return (
    <div className='container pt0'>
        <OrdersView/>
    </div>
  )
}

export default Orders