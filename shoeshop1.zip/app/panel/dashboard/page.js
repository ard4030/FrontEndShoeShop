import Dashboard from '@/Components/Panel/dashboard'
import React from 'react'

const page = () => {
  return (
    <div className='container pt0'>
        <Dashboard />
    </div>
  )
}

export default page