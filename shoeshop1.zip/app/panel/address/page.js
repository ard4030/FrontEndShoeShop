import AddressView from '@/Components/Panel/AddressView'
import React from 'react'

const Address = () => {
  return (
    <div className='container pt0'>
       <AddressView />
    </div>
  )
}

export default Address