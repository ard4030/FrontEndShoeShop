import CommentsView from '@/Components/Panel/CommentsView'
import React from 'react'

const Comments = () => {
  return (
    <div className='container pt0'>
        <CommentsView />
    </div>
  )
}

export default Comments