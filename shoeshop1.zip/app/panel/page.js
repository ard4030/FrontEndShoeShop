// "use client"
import ViewPanel from '@/Components/Panel/ViewPanel'
import React from 'react'

const Panel = () => {
  return (
    <div>
        <ViewPanel />
    </div>
  )
}

export default Panel