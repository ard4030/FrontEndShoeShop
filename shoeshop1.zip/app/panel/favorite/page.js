"use client"
import FavoritView from '@/Components/Panel/FavoritView'
import React from 'react'

const Favorite = () => {
  return (
    <div className='container pt0'>
        <FavoritView />
    </div>
  )
}

export default Favorite