"use client"
import CheckOutView from '@/Components/checkout/CheckOutView'

const page = () => {
  return (
    <div className='container'>
        <CheckOutView />
    </div>
  )
}

export default page