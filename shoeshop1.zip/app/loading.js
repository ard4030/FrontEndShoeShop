import AslLoad from '@/Components/Global/AslLoad'
import React from 'react'

const Loading = () => {
  return (
    <AslLoad />
  )
}

export default Loading